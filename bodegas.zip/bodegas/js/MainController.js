
var app = angular.module('app',['request']).controller('MainController', function ($scope, REQUEST) {
    $scope.refs = [];
    $scope.init = function(){
        $('#tableVenta').DataTable();
        $('#tableBodega').DataTable();

        $("#bodega-tab").click(function(){// show active
            $("#bodega").css("display","block");
            $("#venta").css("display","none");
        });
        $("#venta-tab").click(function(){
            $("#venta").css("display","block");
            $("#bodega").css("display","none");
        });

    }

    $scope.addProduct = function(){
        
    }

    $scope.addSale = function(){
        REQUEST.addSale();
        console.log("aaaa");
        $('#modalVenta').modal('toggle');
        var t = $('#tableVenta').DataTable();
        t.row.add(['MANGO-AR94','0.6','FAC-0000','PEPITO PEREZ','15','19-08-2018']).draw( false );
    }

    $scope.init();
});