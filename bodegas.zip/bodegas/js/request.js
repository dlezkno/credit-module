(function () {
    var app = angular.module('request', ['bussines']);
    app.factory('REQUEST', function (TRANSACTION) {

        var headers = {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Accept': 'application/json, text/javascript, */*; q=0.01'
        };

        var request = {
            addSale:function(){
                TRANSACTION.ajax.request('POST', 'php/read.php',
                {
                    service: 1
                },
                headers,
                function(data){
                    console.log(data);
                    swal.close();
                }, false);
            }
        }

        return request;
        
    });
})();
