<?php
    /*
    require_once 'Excel/reader.php';

    $data = new Spreadsheet_Excel_Reader();
    $data->setOutputEncoding('CP1251');
    $data->read('jxlrwtest.xls');
    echo $data->sheets[0]['cells'][1][1];
    */

    echo "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";

?>