(function () {
    var app = angular.module('request', ['bussines']);
    app.factory('REQUEST', function (TRANSACTION) {

        var headers = {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Accept': 'application/json, text/javascript, */*; q=0.01'
        };

        var request = {
            addSale:function($ref, $tam, $fact, $vendido, $unidades, $fecha, func){
                TRANSACTION.ajax.request('POST', 'php/request.php',
                {
                    service: 5,
                    referencia:$ref,
                    tamano:$tam,
                    factura:$fact,
                    vendido:$vendido,
                    unidades:$unidades,
                    fecha:$fecha
                },
                headers,
                function(data){

                    func(data);
                    swal.close();
                }, false);
            },
            loadExcel:function($file){
                TRANSACTION.ajax.request('POST', 'php/utils/upload.php',
                $file,
                headers,
                function(data){
                    console.log(data);
                    swal.close();
                }, false);
            }
        }

        return request;
        
    });
})();
