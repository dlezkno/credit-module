
var app = angular.module('app',['request']).controller('MainController', function ($scope, REQUEST) {
    $scope.refs = [];
    $scope.sale = {
        ref:{},
        tamano:{},
        fact:"",
        vendido:"",
        unidades:"",
        fecha:""

    };
    $scope.init = function(){   
        $('#tableVenta').DataTable();
        $('#tableBodega').DataTable();

        $("#bodega-tab").click(function(){
            $("#bodega").css("display","block");
            $("#venta").css("display","none");
        });
        $("#venta-tab").click(function(){
            $("#venta").css("display","block");
            $("#bodega").css("display","none");
        });

        $("#file").change(function(){
            $scope.import();
        });

    }

    $scope.addProduct = function(){

    }

    $scope.addSale = function(){
        var sale = $scope.sale;
        console.log(sale);
        //sale.ref.val, sale.tamano.val, sale.fact, sale.vendido, sale.unidades, sale.fecha
        REQUEST.addSale('1', '1', sale.fact, sale.vendido, sale.unidades, sale.fecha,function(data){
            console.log(data);
            $('#modalVenta').modal('toggle');
            var t = $('#tableVenta').DataTable();
            //sale.ref.val, sale.tamano.val, sale.fact, sale.vendido, sale.unidades, sale.fecha
            
            t.row.add(['1', '1', sale.fact, sale.vendido, sale.unidades, '09-08-2018']).draw( false );
            
        });        
    }

    $scope.import = function(){
        console.log("aaaaaaaaaaaa");
        var exl = document.getElementById('file');
        var file = exl.files[0];
        var data = new FormData();
		data.append('file', file);
        REQUEST.loadExcel(data);
    }
    /*
    $scope.addSale = function(){
        REQUEST.addSale();
        console.log("aaaa");
        $('#modalVenta').modal('toggle');
        var t = $('#tableVenta').DataTable();
        t.row.add(['MANGO-AR94','0.6','FAC-0000','PEPITO PEREZ','15','19-08-2018']).draw( false );
    }
    */

    $scope.init();
});