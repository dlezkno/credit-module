<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

class Sale{

    public function update($ref, $fac, $ven, $uni, $fecha, $id){
        
        $Query="UPDATE venta SET 
            referencia = '$ref',
            factura = '$fac',
            vendido = '$ven',
            unidades = '$uni',
            fecha = '$fecha'
            WHERE
            id_sale='$id'";
        
        $Result = mysql_query( $Query );
        $response = new stdClass();
        $response->status = "";
        if (!mysql_error()){		
            return '{"status":"success","message":"Reg updated"}';		
        }else {	
            return '{"status":"fault","message":"'.mysql_error().'","query":"'.$Query.'"}';			   
        }
    }



    public function addSale($con,$ref,$fact,$saleTo,$unit,$date){
        $Query="INSERT INTO venta(referencia,factura,vendido,unidades,fecha)
		VALUES('$ref','$fact','$saleTo','$unit','$date')";	
		mysqli_query($con, $Query);  		
        return "success";
    }

    public function getDataByDate($init, $end){
        $Query="SELECT * FROM sale WHERE
        sale.date BETWEEN '$init' AND '$end'";
        
        $Result = mysql_query( $Query );
        $response = new stdClass();	
        $response->status = 'success';
        $response->producs = array();

        while ($row = mysql_fetch_object($Result)){
            array_push($response->producs, $row);
        }

        return json_encode($response);

    }

}

?>