<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
    
    include_once 'utils/SecurityUtils.php';
    include_once 'utils/sale.php';
    include_once 'utils/cellar.php';
    include_once 'utils/user.php';
    include_once 'utils/connect.php';

    switch ($_POST['service']){
        case '1':
        //logIn
            $user = new User();
            $user->getUser($_POST['pass'],$_POST['email']);
        break;
        case '2':
        //get sales by date
            $request = new sale();
            $user->getDataByDate($_POST['init'],$_POST['end']);
        break;
        case '3':
        break;
        case '4':
        // update sale
            $sale = new Sale();
            $sale->update(
            $_POST['referencia'],
            $_POST['factura'],
            $_POST['vendido'],
            $_POST['unidades'],
            $_POST['fecha'],
            $_POST['id']);
            
        break;
        case '5':
        //add sale
            $con =  new Connect();
            $r = $con->init();
            $sale = new Sale();
            $response = $sale->addSale(
            $r,
            $_POST['referencia'],
            $_POST['factura'],
            $_POST['vendido'],
            $_POST['unidades'],
            $_POST['fecha']);

            echo $response;
        break;
        case '5':
        //generate pass
            $encrypter=new SecurityUtils($_POST['password'],30);
            $password=$encrypter->encode();
            $password=md5($password);
            echo $password;
        break;
        
    }

?>